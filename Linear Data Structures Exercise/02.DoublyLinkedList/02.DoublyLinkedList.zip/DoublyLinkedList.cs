﻿namespace Problem02.DoublyLinkedList
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class DoublyLinkedList<T> : IAbstractLinkedList<T>
    {
        private class Node
        {
            public Node(T element)
            {
                this.Element = element;
            }
            public Node Next { get; set; }
            public Node Previous { get; set; }
            public T Element { get; set; }
        }

        private Node head;
        private Node tail;
        public int Count { get; private set; }

        public void AddFirst(T item)
        {
            Node node = new Node(item);
            if (this.Count == 0)
            {
                this.head = node;
                this.tail = node;
            }
            else
            {
                node.Previous = this.head;
                this.head.Next = node;
                this.head = node;
            }
            this.Count++;
        }

        public void AddLast(T item)
        {
            Node node = new Node(item);

            if (this.head == null)
            {
                this.head = node;
                this.tail = node;
            }
            else
            {
                node.Previous = this.tail;
                this.tail.Next = node;
                this.tail = node;
            }
            this.Count++;
        }

        public T GetFirst()
        {
            CheckForEmptyDoublyLinkedList();
            return this.head.Element;
        }

        public T GetLast()
        {
            CheckForEmptyDoublyLinkedList();
            return this.tail.Element;
        }

        public T RemoveFirst()
        {
            CheckForEmptyDoublyLinkedList();
            T elementToReturn = this.head.Element;
            this.Count--;
            this.head = this.head.Next;
            return elementToReturn;
        }

        public T RemoveLast()
        {
            CheckForEmptyDoublyLinkedList();
            T elementToReturn = this.tail.Element;
            this.Count--;
            this.tail = this.tail.Next;
            return elementToReturn;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node currentNode = this.head;
            while (currentNode != null)
            {
                yield return currentNode.Element;
                currentNode = currentNode.Previous;
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();

        private void CheckForEmptyDoublyLinkedList()
        {
            if (this.Count == 0)
            {
                throw new InvalidOperationException();
            }
        }

    }
}